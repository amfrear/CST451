﻿// ==============================================================================
// File: LogSymptom.cshtml.cs
// Description: Handles the logic for logging a symptom for a selected child.
//              Supports optional pre-selection of child via query string.
// Author: Alex Frear
// Created: July 21, 2025
// ==============================================================================

using System;
using System.Collections.Generic;
using System.Linq;
using MedicalJourneyLog.Data;
using MedicalJourneyLog.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace MedicalJourneyLog.Pages
{
    /// <summary>
    /// PageModel for logging a new symptom entry. Supports optional pre-selection
    /// of a child via query string and builds a dropdown list of available children.
    /// </summary>
    public class LogSymptomModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        /// <summary>
        /// Constructor that injects the application DB context.
        /// </summary>
        /// <param name="context">EF Core database context</param>
        public LogSymptomModel(ApplicationDbContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Optional childId passed via query string (e.g., from child detail page).
        /// </summary>
        [BindProperty(SupportsGet = true)]
        public int? ChildId { get; set; }

        /// <summary>
        /// The bound Symptom model populated from the form.
        /// </summary>
        [BindProperty]
        public Symptom Symptom { get; set; } = new Symptom();

        /// <summary>
        /// Dropdown list of children for the form.
        /// </summary>
        public List<SelectListItem> ChildrenOptions { get; set; } = new();

        /// <summary>
        /// Handles GET requests. Builds the child dropdown and
        /// pre-fills the form if a ChildId was passed.
        /// </summary>
        public void OnGet()
        {
            // Build dropdown with optional pre-selected child
            ChildrenOptions = _context.Children
                .Select(c => new SelectListItem
                {
                    Value = c.Id.ToString(),
                    Text = c.Name,
                    Selected = (ChildId.HasValue && c.Id == ChildId.Value)
                })
                .ToList();

            // Pre-fill child selection and set default DateLogged
            if (ChildId.HasValue)
            {
                Symptom.ChildId = ChildId.Value;
                Symptom.DateLogged = DateTime.Today;
            }
        }

        /// <summary>
        /// Handles POST requests. Validates and saves symptom to the database.
        /// Rebuilds dropdown if form fails validation.
        /// </summary>
        /// <returns>Redirects to Index on success, reloads page on failure</returns>
        public IActionResult OnPost()
        {
            // Always rebuild dropdown to preserve selections on postback
            ChildrenOptions = _context.Children
                .Select(c => new SelectListItem
                {
                    Value = c.Id.ToString(),
                    Text = c.Name,
                    Selected = (Symptom.ChildId == c.Id)
                })
                .ToList();

            if (!ModelState.IsValid)
            {
                return Page();
            }

            // Save symptom to database
            _context.Symptoms.Add(Symptom);
            _context.SaveChanges();

            TempData["SuccessMessage"] = "Symptom logged successfully!";
            return RedirectToPage("Index");
        }
    }
}

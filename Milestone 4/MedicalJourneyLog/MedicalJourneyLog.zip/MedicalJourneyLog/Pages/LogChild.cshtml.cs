﻿// ==============================================================================
// File: LogChild.cshtml.cs
// Description: Handles the creation of new child records via a form. Accepts 
//              user input, validates it, and saves to the database.
// Author: Alex Frear
// Created: July 21, 2025
// ==============================================================================

using MedicalJourneyLog.Data;
using MedicalJourneyLog.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MedicalJourneyLog.Pages
{
    /// <summary>
    /// PageModel for logging (creating) a new child entry.
    /// </summary>
    public class LogChildModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        /// <summary>
        /// Constructor that injects the application's database context.
        /// </summary>
        /// <param name="context">EF Core application DB context</param>
        public LogChildModel(ApplicationDbContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Bound property for the Child form model.
        /// </summary>
        [BindProperty]
        public Child Child { get; set; } = new Child();

        /// <summary>
        /// Handles GET requests. No special logic is needed here.
        /// </summary>
        public void OnGet()
        {
        }

        /// <summary>
        /// Handles POST requests. Validates and saves new child to the database.
        /// </summary>
        /// <returns>Redirects to Index on success, or reloads page on failure.</returns>
        public IActionResult OnPost()
        {
            // Validate input
            if (!ModelState.IsValid)
            {
                return Page();
            }

            // Save new child to the database
            _context.Children.Add(Child);
            _context.SaveChanges();

            // Store success message and redirect
            TempData["SuccessMessage"] = "Child added successfully!";
            return RedirectToPage("Index");
        }
    }
}

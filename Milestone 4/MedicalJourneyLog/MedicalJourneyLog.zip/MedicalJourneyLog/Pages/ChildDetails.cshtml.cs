﻿// ==============================================================================
// File: ChildDetails.cshtml.cs
// Description: Handles the logic for displaying the details of a single child, 
//              including their symptoms. Fetches child data by ID and returns 
//              a 404 error if the child is not found.
// Author: Alex Frear
// Created: July 21, 2025
// ==============================================================================

using MedicalJourneyLog.Data;
using MedicalJourneyLog.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;

namespace MedicalJourneyLog.Pages
{
    /// <summary>
    /// PageModel for the Child Details view. Retrieves a specific child's
    /// profile and symptom history using their unique ID.
    /// </summary>
    public class ChildDetailsModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        /// <summary>
        /// Constructor that injects the database context.
        /// </summary>
        /// <param name="context">EF Core database context</param>
        public ChildDetailsModel(ApplicationDbContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Holds the child data retrieved from the database.
        /// </summary>
        public Child Child { get; set; } = new();

        /// <summary>
        /// Handles GET requests to load a child's profile by ID.
        /// Includes their symptom list using eager loading.
        /// </summary>
        /// <param name="id">The ID of the child to display</param>
        /// <returns>The page result or a 404 if not found</returns>
        public async Task<IActionResult> OnGetAsync(int id)
        {
            // Retrieve child and their symptoms from the database
            Child = await _context.Children
                .Include(c => c.Symptoms)
                .FirstOrDefaultAsync(c => c.Id == id);

            // If no matching child is found, return a 404 Not Found result
            if (Child == null)
            {
                return NotFound();
            }

            return Page();
        }
    }
}
